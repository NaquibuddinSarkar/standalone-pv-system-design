import pandas as pd
import pytest
from standalone_pv_design.sizing import size_standalone_system,cable_area_mm2
from standalone_pv_design.economics import lifecycle_economics

CFG={"interval_hours":1,"design_energy_margin":1.1,"peak_sun_hours":4,"pv_derating_factor":.8,
"inverter_efficiency":.9,"battery_discharge_efficiency":.95,"battery_depth_of_discharge":.8,
"autonomy_days":1,"inverter_sizing_margin":1.25,"inverter_surge_factor":2,
"battery_bus_voltage_v":48,"mppt_current_safety_factor":1.25,"module_rating_w":550,
"module_voc_v":49.5,"controller_max_pv_voltage_v":250}

def test_sizing_positive():
    p=pd.DataFrame({"hour":[0,1,2],"load_kw":[.2,.8,.3]})
    result=size_standalone_system(p,CFG)
    assert result["daily_energy_kwh"]==pytest.approx(1.3)
    assert result["pv_array_kwp_minimum"]>0
    assert result["rounded_module_count"]>=result["module_count_minimum"]

def test_invalid_negative_load():
    with pytest.raises(ValueError): size_standalone_system(pd.DataFrame({"hour":[0],"load_kw":[-1]}),CFG)

def test_cable_calculation():
    r=cable_area_mm2(20,10,48,2)
    assert r["required_area_mm2"]>0
    assert r["next_standard_area_mm2"]>=r["required_area_mm2"]

def test_economics_positive():
    p=pd.DataFrame({"hour":[0,1],"load_kw":[.2,.8]})
    design=size_standalone_system(p,CFG)
    econ_cfg={"project_life_years":10,"discount_rate":.08,"pv_cost_per_kwp":1000,"battery_cost_per_kwh":500,
      "inverter_cost_per_kw":300,"balance_of_system_cost":500,"installation_cost":200,
      "annual_om_fraction":.01,"availability_factor":.95,"annual_pv_degradation_rate":.005,
      "replacement_costs_by_year":{"5":200}}
    econ=lifecycle_economics(econ_cfg,design)
    assert econ["initial_capex"]>0 and econ["lcoe_per_kwh"]>0
