# Standalone PV System Design and Techno-Economic Assessment

A transparent Python sizing toolkit for off-grid / standalone photovoltaic systems. It converts an hourly or typical-day load profile into first-pass PV array, battery, inverter and MPPT requirements, then estimates lifecycle cost, discounted energy and LCOE under explicit assumptions.

> This is a preliminary engineering calculator, not a construction-ready design or electrical safety certification. Verify site solar resource, module/inverter/battery datasheets, temperature derating, voltage limits, cable protection, earthing, short-circuit current, local electrical codes and qualified-engineer sign-off before procurement or installation.

## Quick start

```bash
python -m venv .venv
# activate environment
pip install -r requirements.txt
pip install -e .
pytest -q
python scripts/run_design.py
```

## Inputs

- `data/demo/load_profile_synthetic.csv`: one representative daily profile, with hourly average load in kW.
- `config/design.json`: peak sun hours, derating, inverter and battery efficiencies, autonomy, depth of discharge, bus voltage and illustrative component costs.

Replace the demo load with a measured or defensibly estimated load profile. Distinguish daily average, peak simultaneous load, motor starting surge, seasonal consumption and critical/noncritical loads.


For a local notebook environment, also install `requirements-notebooks.txt`. In Google Colab, open the notebook after this repository is published and install the project with the commands shown in the notebook.

## Methods

- Daily AC energy = sum(hourly average kW × interval hours).
- PV array kWp = design daily AC energy / (PSH × PV derating × inverter efficiency).
- Battery nominal kWh = design daily AC energy × autonomy days / (DoD × battery efficiency × inverter efficiency).
- Inverter continuous kW = peak simultaneous load × design margin; surge rating uses an explicit multiplier.
- MPPT current is a preliminary array-power/DC-bus estimate with margin. String voltage design additionally requires module Voc, temperature coefficient, minimum ambient temperature and controller maximum PV voltage.
- Cable cross-section uses the DC two-conductor voltage-drop approximation. Final cable selection must use installation method, ambient temperature, grouping, fault current, protection coordination and applicable code.
- Lifecycle economics discount annual costs and delivered energy, and account for scheduled battery/inverter replacements if configured.

## Important assumptions

This initial sizing assumes a representative daily profile and an off-grid battery system. A full design should model hourly chronological load and solar resource jointly, loss-of-load probability, autonomy/resilience targets, seasonal extremes, generator backup where relevant, battery aging, charge controller topology and component constraints.
