from __future__ import annotations
import numpy as np

def lifecycle_economics(cfg:dict,design:dict):
    life=int(cfg["project_life_years"]); rate=float(cfg["discount_rate"])
    if life<1 or rate<0: raise ValueError("project life must be positive and discount rate non-negative")
    capex=(design["rounded_array_kwp"]*cfg["pv_cost_per_kwp"]+
           design["battery_nominal_kwh"]*cfg["battery_cost_per_kwh"]+
           design["inverter_continuous_kw_minimum"]*cfg["inverter_cost_per_kw"]+
           cfg["balance_of_system_cost"]+cfg["installation_cost"])
    annual_om=capex*float(cfg["annual_om_fraction"])
    annual_energy=design["daily_energy_kwh"]*365*float(cfg["availability_factor"])
    degradation=float(cfg["annual_pv_degradation_rate"])
    discount_factors=np.array([(1+rate)**(-year) for year in range(1,life+1)])
    delivered=np.array([annual_energy*((1-degradation)**year) for year in range(1,life+1)])
    annual_cost=np.full(life,annual_om,dtype=float)
    for year,cost in cfg.get("replacement_costs_by_year",{}).items():
        y=int(year)
        if 1<=y<=life: annual_cost[y-1]+=float(cost)
    discounted_cost=capex+float(np.sum(annual_cost*discount_factors))
    discounted_energy=float(np.sum(delivered*discount_factors))
    lcoe=discounted_cost/discounted_energy if discounted_energy>0 else float("inf")
    nominal_total_energy=float(delivered.sum())
    return {"initial_capex":float(capex),"annual_om":float(annual_om),
        "annual_energy_year1_kwh":float(annual_energy),"lifetime_energy_kwh":nominal_total_energy,
        "discounted_lifetime_energy_kwh":discounted_energy,"discounted_lifecycle_cost":discounted_cost,
        "lcoe_per_kwh":float(lcoe),"discount_rate":rate,"project_life_years":life}
