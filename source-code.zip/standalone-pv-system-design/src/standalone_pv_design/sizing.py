from __future__ import annotations
import math
import numpy as np
import pandas as pd

STANDARD_CABLE_MM2=[1.5,2.5,4,6,10,16,25,35,50,70,95,120,150,185,240]

def validate_load_profile(profile:pd.DataFrame):
    if not {"hour","load_kw"}.issubset(profile.columns): raise ValueError("load profile requires hour and load_kw")
    p=profile[["hour","load_kw"]].copy()
    p["hour"]=pd.to_numeric(p.hour,errors="raise"); p["load_kw"]=pd.to_numeric(p.load_kw,errors="raise")
    if p.empty or not np.isfinite(p.to_numpy()).all() or (p.load_kw<0).any(): raise ValueError("load profile must be finite, non-empty and non-negative")
    if p.hour.duplicated().any(): raise ValueError("hour values must be unique")
    return p.sort_values("hour")

def size_standalone_system(profile:pd.DataFrame,cfg:dict):
    p=validate_load_profile(profile)
    interval=float(cfg.get("interval_hours",1.0))
    if interval<=0: raise ValueError("interval_hours must be positive")
    daily_energy=float(p.load_kw.sum()*interval)
    peak=float(p.load_kw.max())
    margin=float(cfg["design_energy_margin"])
    psh=float(cfg["peak_sun_hours"]); pv_derate=float(cfg["pv_derating_factor"])
    inv_eff=float(cfg["inverter_efficiency"]); batt_eff=float(cfg["battery_discharge_efficiency"])
    dod=float(cfg["battery_depth_of_discharge"]); autonomy=float(cfg["autonomy_days"])
    if not (0<inv_eff<=1 and 0<batt_eff<=1 and 0<dod<=1 and 0<pv_derate<=1): raise ValueError("efficiency, derating and DoD values must be in (0,1]")
    if psh<=0 or autonomy<0 or margin<1: raise ValueError("PSH must be positive, autonomy non-negative, energy margin >= 1")
    design_energy=daily_energy*margin
    pv_kwp=design_energy/(psh*pv_derate*inv_eff)
    battery_kwh=design_energy*autonomy/(dod*batt_eff*inv_eff)
    inverter_kw=peak*float(cfg["inverter_sizing_margin"])
    inverter_surge_kw=inverter_kw*float(cfg["inverter_surge_factor"])
    dc_voltage=float(cfg["battery_bus_voltage_v"])
    battery_ah=battery_kwh*1000/dc_voltage
    controller_a=pv_kwp*1000/dc_voltage*float(cfg["mppt_current_safety_factor"])
    module_w=float(cfg["module_rating_w"])
    module_count=math.ceil(pv_kwp*1000/module_w)
    # Preliminary string calculation only; cold-temperature Voc check remains required.
    voc=float(cfg["module_voc_v"])
    max_pv_voltage=float(cfg["controller_max_pv_voltage_v"])
    series=max(1,int(max_pv_voltage//voc))
    strings=math.ceil(module_count/series)
    actual_modules=series*strings
    actual_pv_kwp=actual_modules*module_w/1000
    return {
        "daily_energy_kwh":daily_energy,"design_daily_energy_kwh":design_energy,
        "peak_load_kw":peak,"pv_array_kwp_minimum":pv_kwp,
        "battery_nominal_kwh":battery_kwh,"battery_capacity_ah":battery_ah,
        "inverter_continuous_kw_minimum":inverter_kw,"inverter_surge_kw_minimum":inverter_surge_kw,
        "mppt_output_current_a_minimum":controller_a,
        "module_count_minimum":module_count,"modules_in_series_preliminary":series,
        "parallel_strings_preliminary":strings,"rounded_module_count":actual_modules,
        "rounded_array_kwp":actual_pv_kwp,
        "controller_voltage_check_required":True,
        "design_note":"Preliminary sizing only. Verify cold-corrected Voc, Isc, inverter surge, protection, earthing, cable installation and applicable code."
    }

def cable_area_mm2(current_a,one_way_length_m,system_voltage_v,voltage_drop_pct=2.0,resistivity_ohm_mm2_per_m=.0175):
    """DC two-conductor voltage-drop estimate: A=2*L*I*rho/DeltaV."""
    if min(current_a,one_way_length_m,system_voltage_v,voltage_drop_pct,resistivity_ohm_mm2_per_m)<=0: raise ValueError("inputs must be positive")
    delta_v=system_voltage_v*voltage_drop_pct/100
    required=2*one_way_length_m*current_a*resistivity_ohm_mm2_per_m/delta_v
    selected=next((x for x in STANDARD_CABLE_MM2 if x>=required),None)
    return {"required_area_mm2":required,"next_standard_area_mm2":selected,
            "note":"Preliminary voltage-drop result only; ampacity, installation method, temperature, grouping and fault protection may require a larger conductor."}
