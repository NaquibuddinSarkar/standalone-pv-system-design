# Preliminary sizing method and engineering checklist

## Load assessment

The input file represents hourly average AC load. Daily energy is the sum of load_kW times interval_hours. The peak is the highest interval average, not necessarily the true sub-second inrush or simultaneous surge. For motor loads, collect starting current, power factor, duty cycle and starting method.

## Array sizing

PV kWp = design_daily_AC_energy / (peak_sun_hours × PV_derating × inverter_efficiency). PSH must be based on site coordinates, tilt, shading and worst-month design criterion. A single average PSH can under-size a system in the monsoon / low-solar period.

## Battery sizing

Nominal battery kWh = design_daily_AC_energy × autonomy_days / (DoD × battery_discharge_efficiency × inverter_efficiency). Confirm the manufacturer's usable energy, C-rate, low-temperature behaviour, end-of-life capacity, cycle-life curve and BMS limits. Do not assume nominal capacity equals usable energy.

## Electrical checks not completed by this calculator

- Cold-corrected module open-circuit voltage and controller input limit.
- String current, Isc correction, parallel string count and fuse/breaker ratings.
- Inverter DC input range, continuous power, surge duration, waveform and power factor.
- Cable ampacity under the actual installation method, grouping and ambient temperature.
- Voltage drop under normal and peak conditions.
- DC/AC isolators, overcurrent and surge protection, earthing, bonding and lightning protection.
- Battery enclosure, ventilation/thermal management, fire safety and BMS compatibility.
- Structural loading, wind uplift, mounting and rooftop waterproofing.
- Local standards, utility rules, commissioning tests and qualified engineering sign-off.

The cable calculation uses a simplified DC two-conductor resistance approximation and does not replace ampacity or fault-current calculations.

## Economic model

LCOE = discounted life-cycle cost / discounted delivered energy. Configured replacement costs are entered by year. The base calculation is pre-tax, unlevered and excludes salvage, financing, tax, degradation uncertainty, battery capacity fade beyond scheduled replacement and downtime beyond the availability factor. Add these where project feasibility requires them.
