# Data provenance

The supplied 24-hour load profile is synthetic and illustrative. No measured household, industrial or institutional electricity consumption is included.

For a Bangladesh design, collect measured interval load, site coordinates, shading survey, month-by-month solar resource, minimum ambient temperature and vendor datasheets. Record device model, measurement dates, instrument accuracy, time zone and any scaling. Cost inputs must come from dated quotations and clearly specify VAT, transport, duties, installation and warranties.
