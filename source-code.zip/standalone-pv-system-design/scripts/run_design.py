from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
from standalone_pv_design.sizing import size_standalone_system,cable_area_mm2
from standalone_pv_design.economics import lifecycle_economics
ROOT=Path(__file__).resolve().parents[1]
def main():
    cfg=json.loads((ROOT/"config/design.json").read_text())
    load=pd.read_csv(ROOT/"data/demo/load_profile_synthetic.csv")
    design=size_standalone_system(load,cfg)
    economics=lifecycle_economics(cfg,design)
    output={"engineering_sizing":design,"techno_economic":economics,
            "example_cable_check":cable_area_mm2(design["mppt_output_current_a_minimum"],10,cfg["battery_bus_voltage_v"],2)}
    (ROOT/"outputs").mkdir(exist_ok=True); (ROOT/"figures").mkdir(exist_ok=True)
    (ROOT/"outputs/design_summary.json").write_text(json.dumps(output,indent=2)+"\n")
    ax=load.plot(x="hour",y="load_kw",legend=False,figsize=(9,4))
    ax.set(title="Synthetic representative-day load profile",xlabel="Hour of day",ylabel="Average load (kW)"); ax.grid(alpha=.2)
    ax.figure.tight_layout(); ax.figure.savefig(ROOT/"figures/daily_load_profile.png",dpi=150)
    print(json.dumps(output,indent=2))
if __name__=="__main__":main()
